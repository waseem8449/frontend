import React, { useState } from "react";
import { NavLink, useHistory } from "react-router-dom";
const Addcity = () => {
  const history = useHistory("");
  const token = localStorage.getItem("token");

  const [city, setCity] = useState([]);

  const addinpdata = async (e) => {
    e.preventDefault();
    console.log(city);
    const res = await fetch("/addCity", {
      method: "POST",
      headers: {
        "content-Type": "application/json",
        authorization: token ? `${token}` : "",
      },
      body: JSON.stringify({
        city,
      }),
    });
    const data = await res.json();
    console.log(data);
    if (res.status === 404 || !data) {
      alert("error");
      console.log("error");
    } else {
      alert("data added");
      history.push("/Home");
      console.log("data added");
    }
  };
  return (
    <div className="container mt-5 border border-primary">
      <h1 className="mt-5 text-center">Add your city</h1>
      <form className="mt-5">
        <div className="mb-3  ">
          <label htmlFor="name" className="form-label">
            city
          </label>
          <input
            type="text"
            value={city}
            placeholder="add your city"
            onChange={(e) => {
              setCity(e.target.value);
            }}
            className="form-control"
            name="name"
            id="name"
          />
        </div>

        <div className="btns text-center">
          <button
            type="submit"
            onClick={addinpdata}
            className="btn btn-primary "
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default Addcity;
