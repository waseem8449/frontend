import React, { useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";
const Login = ({ setLoginUser }) => {
  const history = useHistory();
  const [user, setUser] = useState({
    name: "",
    password: "",
  });
  const setdata = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user, //spread operator
      [name]: value,
    });
  };

  const login = async (e) => {
    e.preventDefault();
    const res = await axios.post("/Login", user);
    // const data = await res.json();
    // const { token } = data;
    const token = res.data.token;
    localStorage.setItem("token", token);

    if (res) {
      alert("login sucessfully");
      history.push("/Home");
    } else {
      alert("error");
    }
  };

  return (
    <>
      <div className="flex flex-col w-full max-w-md px-4 py-8 bg-white rounded-lg shadow dark:bg-gray-800 sm:px-6 md:px-8 lg:px-10 mt-5">
        <div className="self-center mb-6 text-5xl font-light text-gray-600 sm:text-5xl dark:text-white">
          Login To Your Account
        </div>
        <div
          className="mt-8"
          style={{
            backgroundImage: `url("pexel.webp")`,
          }}
        >
          <form action="#" autoComplete="off">
            <div className="row">
              <div className="mb-3">
                <div className="mb-3 col-lg-6 col-md-6 col-12">
                  <label htmlFor="InputEmail1" className="form-label">
                    Email address
                  </label>
                  <input
                    type="email"
                    value={user.email}
                    onChange={setdata}
                    className="form-control"
                    id="email"
                    name="email"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div className="mb-3 col-lg-6 col-md-6 col-12">
                  <label htmlFor="InputPassword1" className="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    id="sign-in-email"
                    className="form-control"
                    name="password"
                    value={user.password}
                    onChange={setdata}
                    placeholder="Your password"
                  />
                </div>
                <button
                  type="submit"
                  onClick={(e) => login(e)}
                  className="onChange={setdata}btn btn-primary"
                >
                  Submit
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};
export default Login;
