import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import Navbar from "./component/Navbar";
import Home from "./component/Home";
import Register from "./component/Register";
import { Switch, Route } from "react-router-dom";
import Login from "./component/Login";
import Addcity from "./component/Addcity";
function App() {
  return (
    <header>
      <Navbar />
      <Switch>
        <Route exact path="/" component={Register} />
        <Route exact path="/Login" component={Login} />
        <Route exact path="/Home" component={Home} />
        <Route exact path="/addCity" component={Addcity} />
      </Switch>
    </header>
  );
}

export default App;
